package com.capgemini.view;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.exception.CustomerValidation;
import com.capgemini.service.BusServiceImpl;
import com.capgemini.service.IBusService;

public class MainClient 
{
	private IBusService busService ;
	
	public MainClient() 
	{
		busService = new BusServiceImpl() ;
	}

	public static void main(String[] args)
	{
		MainClient main = new MainClient() ;
		while(true)
		{
			main.showMenu();
		}
	}
	
	public void showMenu()
	{
		Scanner scanner = new Scanner(System.in) ;
		
		System.out.println("1. Book Ticket ");
		System.out.println("2. Exit ");
		
		System.out.println("");
		System.out.println("Enter Your Choice ");
		int choice = scanner.nextInt() ;
		
		switch( choice )
		{
			case 1 : bookTicket() ;
				break ;
			
			case 2 : System.out.println("Thanks For Visiting.....");
					 System.exit(0) ;
				break ;
				
			default : System.out.println("Enter valid Input ");
				break ;
		}
	}

	private void bookTicket()
	{
		try
		{
			Scanner scanner = new Scanner( System.in ) ;
			ArrayList<BusBean> buses = busService.retrieveBusDetails() ;
			
			Iterator<BusBean> it = buses.iterator() ;
			
			System.out.println("BUSID \t\t  BusType \t\t From \t\t To \t\t AvailableSeat \t\t Fare \t\t JourneyDate ");
			
			while( it.hasNext() )
			{
				BusBean bus = it.next() ;
				
				System.out.println(bus.getBusId() + "\t\t "+ bus.getBusType() + "\t\t "+ bus.getFromStop()  + "\t\t "+ bus.getToStop() 
						 + "\t\t "+ bus.getAvailableSeats()  + "\t\t "+ bus.getFare()  + "\t\t "+ bus.getDateOfJourney());
			}
			
			System.out.println("");
			
			System.out.println("Do You want To Book Ticket (y/n)");
			
			char reply = scanner.next().toLowerCase().charAt(0);
			
			if(reply == 'y')
			{
				System.out.println("");
				
				System.out.println("Enter Customer Id (A100000) ");
				String custid = scanner.next() ;
				
				Pattern patter = Pattern.compile("^[A-Z]{1}[0-9]{6}$") ;
				Matcher match = patter.matcher(custid);
				if(!match.matches())
				{
					throw new CustomerValidation() ;
				}
				
				System.out.println("Enter Bus Id ");
				int busid = scanner.nextInt() ;
				
				System.out.println("Enter Number of Seats  ");
				int seats = scanner.nextInt() ;
				
				BookingBean booking = new BookingBean() ;
				booking.setCustId(custid);
				booking.setBusId(busid);
				booking.setNoOfSeat(seats);
				
				int id = busService.bookTicket(booking) ;
				System.out.println("");
				System.out.println("Thank you . Your Booking id is " + id);
				System.out.println("");
				
				
			}
		}
		catch( BookingException e)
		{
			//e.printStackTrace();
		}
		catch( Exception e)
		{
			//e.printStackTrace();
		}
	}

}
