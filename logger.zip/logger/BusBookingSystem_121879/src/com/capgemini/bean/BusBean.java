package com.capgemini.bean;

import java.sql.Date;
import java.time.LocalDate;

public class BusBean
{
	private int busId ;
	private String busType ;
	private Date dateOfJourney ;
	private String fromStop ;
	private String toStop ;
	private int availableSeats ;
	private int fare ;
	
	@Override
	public String toString() {
		return "BusBean [busId=" + busId + ", busType=" + busType
				+ ", dateOfJourney=" + dateOfJourney + ", fromStop=" + fromStop
				+ ", toStop=" + toStop + ", availableSeats=" + availableSeats
				+ ", fare=" + fare + "]";
	}

	public BusBean(int busId, String busType, Date dateOfJourney,
			String fromStop, String toStop, int availableSeats, int fare) {
		super();
		this.busId = busId;
		this.busType = busType;
		this.dateOfJourney = dateOfJourney;
		this.fromStop = fromStop;
		this.toStop = toStop;
		this.availableSeats = availableSeats;
		this.fare = fare;
	}
	
	
	public BusBean() 
	{
		// TODO Auto-generated constructor stub
	}

	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public Date getDateOfJourney() {
		return dateOfJourney;
	}

	public void setDateOfJourney(Date date) {
		this.dateOfJourney = date;
	}

	public String getFromStop() {
		return fromStop;
	}

	public void setFromStop(String fromStop) {
		this.fromStop = fromStop;
	}

	public String getToStop() {
		return toStop;
	}

	public void setToStop(String toStop) {
		this.toStop = toStop;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + busId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BusBean other = (BusBean) obj;
		if (busId != other.busId)
			return false;
		return true;
	}
	
	
}
