package com.capgemini.exception;

public class CustomerValidation extends Exception
{
	public CustomerValidation() 
	{
		System.out.println("Customer Id Should start with A-Z and contain 6 numbers e.g:= A100000");
	}
}
