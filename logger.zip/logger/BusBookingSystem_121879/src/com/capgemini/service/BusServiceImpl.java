package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDAOImpl;
import com.capgemini.dao.IBusDAO;
import com.capgemini.exception.BookingException;

public class BusServiceImpl implements IBusService 
{

	private IBusDAO busDAO ;
	
	public BusServiceImpl() 
	{
		busDAO = new BusDAOImpl();
	}
	@Override
	public ArrayList<BusBean> retrieveBusDetails() {
		// TODO Auto-generated method stub
		return busDAO.retrieveBusDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		return busDAO.bookTicket(bookingBean);
	}

}
