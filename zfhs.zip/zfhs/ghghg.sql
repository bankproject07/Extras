select * from ACCOUNT_MASTER;

select * from CUSTOMER ;

drop sequence custid_seq;



create sequence custid_seq start with 1500243 increment by 1 nocache;
select custid_seq.nextVal from dual;

select accid_seq.nextVal from dual;

select accid_seq from dual

drop sequence accid_seq;

create sequence accid_seq start with 12001200 increment by 1 nocache;

select * from REQUESTTABLE;