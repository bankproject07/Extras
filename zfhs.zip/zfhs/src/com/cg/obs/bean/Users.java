package com.cg.obs.bean;

public class Users {
	

	private int userId;
	private Long accountId;
	private String loginPassword;
	private String secretQuestion;
	private String secretAns;
	private String transPassword;
	private String lockStatus;

	public Users() 
	{
		super();
	}


	public Users(Long accountId, int userId, String loginPassword, String secretQuestion, String secretAns,
			String transPassword, String lockStatus) {
		super();
		this.accountId = accountId;
		this.userId = userId;
		this.loginPassword = loginPassword;
		this.secretQuestion = secretQuestion;
		this.secretAns = secretAns;
		this.transPassword = transPassword;
		this.lockStatus = lockStatus;
	}


	public String getSecretAns() {
		return secretAns;
	}


	public void setSecretAns(String secretAns) {
		this.secretAns = secretAns;
	}


	public Long getAccountId() 
	{
		return accountId;
	}

	public void setAccountId(Long accountId)
	{
		this.accountId = accountId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId)
	{
		this.userId = userId;
	}

	public String getLoginPassword()
	{
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword)
	{
		this.loginPassword = loginPassword;
	}

	public String getSecretQuestion() 
	{
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) 
	{
		this.secretQuestion = secretQuestion;
	}

	public String getTransPassword() 
	{
		return transPassword;
	}

	public void setTransPassword(String transPassword) 
	{
		this.transPassword = transPassword;
	}

	public String getLockStatus()
	{
		return lockStatus;
	}

	public void setLockStatus(String lockStatus) 
	{
		this.lockStatus = lockStatus;
	}

	
	@Override
	public String toString() {
		return "Users [accountId=" + accountId + ", userId=" + userId + ", loginPassword=" + loginPassword
				+ ", secretQuestion=" + secretQuestion + ", secretAns=" + secretAns + ", transPassword=" + transPassword
				+ ", lockStatus=" + lockStatus + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + userId;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Users other = (Users) obj;
		if (userId != other.userId)
			return false;
		return true;
	}





}

